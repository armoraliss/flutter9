package com.example.bloc_with_json

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
